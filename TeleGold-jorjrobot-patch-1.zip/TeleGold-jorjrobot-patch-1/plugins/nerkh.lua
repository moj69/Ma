do

function run(msg, matches)
  return "💰تعرفه دریافت گروه ضد اسپم با ربات WaderTG\nمبلغ قابل پرداخت💶5,000 تومن\n⚠️نکته مهم کسانی که گروه دارند که اعضای آن بالای100 نفر است\nربات به گروه شما به صورت رایگان اضافه میشود😎\nادمین های ربات WaderTGجهت در خواست گروه ضد اسپم\n@mohammadsdi4799\n@iphonei\n@AMiN1779\n@Oo_hamed_ice_fuckeram_Oo\n"
end

return {
  description = " bot nerkh", 
  usage = "nerkh",
  patterns = {
    "^nerkh$",
    "^[!/#]nerkh$"
  }, 
  run = run 
}

end
